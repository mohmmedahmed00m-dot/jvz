# 🚀 دليل الإعداد السريع

## المتطلبات الأساسية
- Node.js 20+
- PostgreSQL 17+
- Redis 7+
- أو Docker

## الإعداد السريع (Docker)

```bash
# 1. انسخ ملف البيئة
cp backend/.env.example backend/.env

# 2. عدّل المفاتيح في backend/.env
# أضف على الأقل Groq API key (مجاني):
# GROQ_API_KEY=gsk_...
# AI_PROVIDER=groq
# AI_USE_REAL_LLM=true

# 3. شغّل المشروع
docker-compose up -d

# 4. افتح المتصفح
open http://localhost:5173
```

## الإعداد اليدوي (بدون Docker)

```bash
# 1. تثبيت PostgreSQL و Redis
sudo apt-get install postgresql redis-server

# 2. تشغيل dev-up.sh
bash dev-up.sh

# 3. تشغيل Backend
cd backend
npm install
npm run start:dev

# 4. تشغيل Frontend (في terminal جديد)
cd frontend
npm install
npm run dev
```

## الحصول على مفاتيح API

### Groq (مجاني 100% - مُوصى به)
1. https://console.groq.com
2. سجل بحساب Google
3. ولّد مفتاح API
4. انسخه إلى `.env`

### خيارات أخرى
- **OpenAI**: https://platform.openai.com (مدفوع)
- **Anthropic**: https://console.anthropic.com (مدفوع)
- **Gemini**: https://aistudio.google.com (مجاني محدود)

## بيانات الدخول التجريبية

- **Email**: أي بريد إلكتروني
- **Password**: أي كلمة مرور (8+ أحرف)
- **License Key**: `ALK-DEMO-TEST-0001-0001`

## المجلدات المهمة

```
/backend        - NestJS Backend API
/frontend       - React Frontend
/e2e           - End-to-end tests
/docker-compose.yml - Docker configuration
/dev-up.sh     - Bootstrap script
```

## المنفذات

- Frontend: http://localhost:5173
- Backend API: http://localhost:3000/api
- PostgreSQL: localhost:5432
- Redis: localhost:6379

## الدعم

للمزيد من المعلومات، راجع:
- `README.md` - دليل شامل
- `PRODUCTION_READY_REPORT.md` - تقرير الجاهزية
- `REAL_AUDIT_REPORT.md` - تقرير المراجعة
