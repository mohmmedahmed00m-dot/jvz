import { Injectable, NotFoundException, BadRequestException, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource, QueryFailedError } from 'typeorm';
import { randomUUID, timingSafeEqual, createHash } from 'crypto';
import { License, User } from '../../database/entities';
import { NotificationsService } from '../notifications/notifications.service';
import { EncryptionService } from '../../common/crypto/encryption.service';

export interface JvzooIpnPayload {
  [key: string]: string;
}

/** Constant-time string comparison (defends signature checks against timing attacks). */
function safeEqualHex(a: string, b: string): boolean {
  const ab = Buffer.from(a, 'hex');
  const bb = Buffer.from(b, 'hex');
  if (ab.length !== bb.length || ab.length === 0) return false;
  return timingSafeEqual(ab, bb);
}

@Injectable()
export class LicensingService {
  private readonly logger = new Logger('Licensing');

  constructor(
    @InjectRepository(License) private readonly licenseRepo: Repository<License>,
    @InjectRepository(User) private readonly userRepo: Repository<User>,
    private readonly notifications: NotificationsService,
    private readonly dataSource: DataSource,
    private readonly encryption: EncryptionService,
  ) {}

  /** Returns the live license status for a user ('none' if no license linked). */
  async getUserLicenseStatus(userId: string): Promise<string> {
    const user = await this.userRepo.findOne({
      where: { id: userId },
      relations: ['license'],
    });
    if (!user) return 'none';
    if (!user.license) return 'none';
    return user.license.status; // active / revoked / refunded
  }

  /** Finds a license ID by its plain-text key (keys are encrypted at rest). */
  private async findLicenseIdByKey(licenseKey: string): Promise<string> {
    const rows = await this.licenseRepo.query(
      `SELECT id, license_key FROM licenses WHERE status = 'active'`,
    );
    const row = rows.find((r: any) => this.encryption.decrypt(r.license_key) === licenseKey);
    if (!row) {
      throw new BadRequestException({ code: 'INVALID_LICENSE', message: 'Invalid license key' });
    }
    return row.id;
  }

  /** Validates a license key exists and is active. Uses raw SQL to avoid TypeORM identity map. */
  async validateLicenseKey(licenseKey: string): Promise<License> {
    const licenseId = await this.findLicenseIdByKey(licenseKey);
    const license = await this.licenseRepo.findOne({ where: { id: licenseId } });
    if (!license) {
      throw new BadRequestException({ code: 'INVALID_LICENSE', message: 'Invalid license key' });
    }
    // Return the entity — callers should NOT save it back
    return license;
  }

  /** Decrypt a license key for display/email purposes only. */
  private decryptLicenseKey(license: License): string {
    return this.encryption.decrypt(license.license_key);
  }

  /** Links a license to a user and stamps activated_at (Section 6.3 flow). */
  async activateLicenseForUser(userId: string, licenseKey: string): Promise<{ status: string; activated_at: Date }> {
    // Step 1: Find the license ID using raw SQL (avoids TypeORM entity tracking/identity map)
    const rows = await this.licenseRepo.query(
      `SELECT id, license_key FROM licenses WHERE status = 'active'`,
    );
    let licenseId: string | undefined;
    for (const row of rows) {
      const decrypted = this.encryption.decrypt(row.license_key);
      if (decrypted === licenseKey) {
        licenseId = row.id;
        break;
      }
    }
    if (!licenseId) {
      throw new BadRequestException({ code: 'INVALID_LICENSE', message: 'Invalid license key' });
    }

    // Step 2: Do all writes via raw SQL only (no entity tracking)
    return this.dataSource.transaction(async (mgr) => {
      const userRows = await mgr.query(`SELECT license_id FROM users WHERE id = $1`, [userId]);
      if (!userRows.length) throw new NotFoundException('User not found');

      const existingLicenseId = userRows[0].license_id;
      if (existingLicenseId && existingLicenseId !== licenseId) {
        throw new BadRequestException({
          code: 'LICENSE_ALREADY_LINKED',
          message: 'This account already has a different license linked',
        });
      }

      // Update user license link
      await mgr.query(`UPDATE users SET license_id = $1 WHERE id = $2`, [licenseId, userId]);

      // Set activated_at only if not already set
      await mgr.query(
        `UPDATE licenses SET activated_at = COALESCE(activated_at, NOW()) WHERE id = $1`,
        [licenseId],
      );

      this.logger.log(`License activated for user ${userId}`);
      const licRows = await mgr.query(`SELECT activated_at FROM licenses WHERE id = $1`, [licenseId]);
      return { status: 'active', activated_at: licRows[0]?.activated_at ?? new Date() };
    });
  }

  /**
   * JVZoo IPN verification (Section 6.1). Implements JVZoo's standard cverify
   * algorithm: sort all params except 'cverify' by key, concatenate values,
   * append the JVZOO_SECRET_KEY, MD5 the result, compare to received cverify.
   * Comparison is CONSTANT-TIME (timingSafeEqual) to prevent signature forgery.
   */
  verifyJvzooSignature(payload: JvzooIpnPayload, secret: string): boolean {
    const received = payload['cverify'];
    if (!received) return false;
    const fields = { ...payload };
    delete fields['cverify'];
    const keys = Object.keys(fields).sort();
    const concatenated = keys.map((k) => fields[k] ?? '').join('') + secret;
    const computed = createHash('md5').update(concatenated).digest('hex');
    return safeEqualHex(computed.toLowerCase(), received.toLowerCase());
  }

  /**
   * Processes a JVZoo INS payload after signature verification.
   *  - SALE: create an active License, idempotent on jvzoo_transaction_id.
   *    The UNIQUE partial index guarantees exactly one license per txn even
   *    under concurrent IPN delivery; a duplicate insert is resolved to the
   *    already-stored license (audit fix #2/#3).
   *  - REFUND / CGBK: revoke the License by transaction id within a single
   *    transaction (audit fix #10). Cascade access revocation is enforced by
   *    LicenseGuard reading the live DB status on each protected request.
   */
  async handleJvzooIpn(payload: JvzooIpnPayload): Promise<{ status: string }> {
    const txnType = (payload['ctransaction'] || '').toUpperCase();
    const txnId = payload['ctransreceipt'] || '';
    const customerEmail = payload['ccustemail'] || '';

    this.logger.log(`JVZoo IPN received: txnType=${txnType} txnId=${txnId}`);

    if (txnType === 'SALE') {
      const existing = txnId
        ? await this.licenseRepo.findOne({ where: { jvzoo_transaction_id: txnId } })
        : null;
      let license = existing;
      if (!license) {
        const licenseKey = this.generateLicenseKey();
        const candidate = this.licenseRepo.create({
          license_key: this.encryption.encrypt(licenseKey), // Encrypt at rest
          source: 'jvzoo',
          jvzoo_transaction_id: txnId || null,
          status: 'active',
        });
        try {
          // Insert within a transaction. The DB UNIQUE index is the final
          // idempotency guard: a concurrent duplicate insert throws 23505 and
          // we resolve to the already-stored license.
          license = await this.dataSource.transaction(async (mgr) => mgr.save(candidate));
          this.logger.log(`Created license ${license.license_key} for txn ${txnId}`);
        } catch (err) {
          if (err instanceof QueryFailedError && (err as any).code === '23505' && txnId) {
            license = await this.licenseRepo.findOne({ where: { jvzoo_transaction_id: txnId } });
            this.logger.log(`Idempotent: license for txn ${txnId} already existed`);
          } else {
            throw err;
          }
        }
      }
      if (license && customerEmail) {
        // Decrypt license key before sending to customer
        const decryptedKey = this.decryptLicenseKey(license);
        await this.notifications.sendLicenseKey(customerEmail, decryptedKey);
      }
      return { status: 'ok' };
    }

    if (txnType === 'REFUND' || txnType === 'CGBK') {
      const finalStatus = txnType === 'REFUND' ? 'refunded' : 'revoked';
      await this.dataSource.transaction(async (mgr) => {
        const license = txnId
          ? await mgr.findOne(License, { where: { jvzoo_transaction_id: txnId } })
          : null;
        if (license) {
          license.status = finalStatus;
          await mgr.save(license);
          this.logger.warn(`License ${license.license_key} set to ${finalStatus} (txn ${txnId})`);
        } else {
          this.logger.warn(`Refund/chargeback for unknown txn ${txnId}`);
        }
      });
      return { status: 'ok' };
    }

    this.logger.log(`JVZoo IPN ignored (txnType=${txnType})`);
    return { status: 'ignored' };
  }

  private generateLicenseKey(): string {
    // Human-friendly, unguessable license key: ALK-XXXX-XXXX-XXXX-XXXX
    const part = () => randomUUID().replace(/-/g, '').slice(0, 4).toUpperCase();
    return `ALK-${part()}-${part()}-${part()}-${part()}`;
  }
}
