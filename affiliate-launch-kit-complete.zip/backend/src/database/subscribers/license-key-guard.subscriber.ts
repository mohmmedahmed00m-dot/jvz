import { EventSubscriber, EntitySubscriberInterface, UpdateEvent } from 'typeorm';
import { License } from '../entities';

/**
 * TypeORM Subscriber that protects the `license_key` column from accidental
 * overwrite. License keys are encrypted with AES-256-GCM at rest; any
 * unencrypted value that gets assigned to license_key (e.g. via TypeORM
 * auto-save of a tracked entity) would destroy the encrypted data.
 *
 * This subscriber intercepts all UPDATE operations on the License entity and
 * strips the license_key from the update payload if it doesn't start with the
 * `$aes256gcm$` encryption marker.
 */
@EventSubscriber()
export class LicenseKeyGuardSubscriber implements EntitySubscriberInterface<License> {
  listenTo() {
    return License;
  }

  beforeUpdate(event: UpdateEvent<License>) {
    console.log('[LicenseKeyGuard] beforeUpdate fired!', event.entity?.license_key?.substring(0, 20));
    if (!event.entity) return;
    const key = event.entity.license_key;
    // If license_key is being set to a non-encrypted value, strip it from the update
    if (key && !key.startsWith('$aes256gcm$')) {
      console.log('[LicenseKeyGuard] BLOCKING plain-text license_key update!');
      delete event.entity.license_key;
    }
  }
}
