import { NestFactory } from '@nestjs/core';
import { ValidationPipe, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import cookieParser from 'cookie-parser';
import helmet from 'helmet';
import { AppModule } from './app.module';
import { AllExceptionsFilter } from './common/filters/http-exception.filter';

function assertProductionSecrets() {
  if (process.env.NODE_ENV !== 'production') return;
  const REQUIRED = [
    'DATABASE_URL',
    'JWT_SECRET',
    'JWT_REFRESH_SECRET',
    'JVZOO_SECRET_KEY',
    'ENCRYPTION_KEY',
  ];
  const INSECURE = ['dev-insecure', 'placeholder', 'fake', 'secret'];

  const errors: string[] = [];
  for (const key of REQUIRED) {
    const val = process.env[key] ?? '';
    if (!val) {
      errors.push(`${key} is missing`);
    } else if (INSECURE.some((bad) => val.toLowerCase().includes(bad))) {
      errors.push(`${key} contains an insecure placeholder value`);
    }
  }

  // Validate that the selected AI provider has a real API key
  const provider = (process.env.AI_PROVIDER ?? 'anthropic').toLowerCase();
  const providerKeyMap: Record<string, string> = {
    anthropic: 'ANTHROPIC_API_KEY',
    openai: 'OPENAI_API_KEY',
    gemini: 'GEMINI_API_KEY',
    claude: 'ANTHROPIC_API_KEY',
    gpt: 'OPENAI_API_KEY',
    google: 'GEMINI_API_KEY',
  };
  const providerKey = providerKeyMap[provider] ?? 'ANTHROPIC_API_KEY';
  const keyVal = process.env[providerKey] ?? '';
  if (!keyVal || INSECURE.some((bad) => keyVal.toLowerCase().includes(bad))) {
    errors.push(`${providerKey} is required for AI_PROVIDER=${provider} but is missing or insecure`);
  }

  if (errors.length) {
    console.error('FATAL: Production secrets validation failed:\n' + errors.map(e => `  - ${e}`).join('\n'));
    process.exit(1);
  }
}

async function bootstrap() {
  assertProductionSecrets();
  const app = await NestFactory.create(AppModule, { bufferLogs: true });
  const config = app.get(ConfigService);
  const port = config.get<number>('PORT') ?? 3000;
  const frontendUrl = config.get<string>('FRONTEND_BASE_URL') ?? 'http://localhost:5173';

  app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
  app.use(cookieParser());

  app.enableCors({
    origin: [frontendUrl, 'http://127.0.0.1:5173', 'http://localhost:5173'],
    credentials: true,
    methods: ['GET', 'POST', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
  });

  app.setGlobalPrefix('api');
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      transform: true,
      forbidNonWhitelisted: false,
    }),
  );
  app.useGlobalFilters(new AllExceptionsFilter());

  await app.listen(port);
  new Logger('Bootstrap').log(`🚀 Backend listening on http://localhost:${port}/api (NODE_ENV=${config.get('NODE_ENV')}, AI_PROVIDER=${config.get('AI_PROVIDER')}, AI_USE_REAL_LLM=${config.get('AI_USE_REAL_LLM')})`);
}
bootstrap();
