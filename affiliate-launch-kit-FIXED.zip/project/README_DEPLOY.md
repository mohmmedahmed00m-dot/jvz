# دليل النشر — Affiliate Launch Kit

## قبل النشر: اجمع هذه المتغيرات

```bash
# 1. توليد المفاتيح الآمنة (شغّل كل سطر منفصل)
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
# شغّله 4 مرات واحفظ النتائج كـ:
# JWT_SECRET
# JWT_REFRESH_SECRET
# HASH_SECRET
# ENCRYPTION_KEY

# 2. مفاتيح API جاهزة عندك:
# GROQ_API_KEY      = مفتاح Groq الجديد (بعد إلغاء القديم)
# EMAIL_PROVIDER_API_KEY = مفتاح Resend الجديد (بعد إلغاء القديم)
```

---

## النشر على Railway (الأسهل)

```
1. railway.app → New Project → Deploy from GitHub
2. اربط الـ repo
3. أضف PostgreSQL Plugin + Redis Plugin
4. Environment Variables → أضف كل المتغيرات أدناه
5. Deploy → انتهى
```

### متغيرات البيئة المطلوبة على Railway:
```
NODE_ENV=production
DATABASE_URL=(Railway يعطيك هذا تلقائياً)
REDIS_URL=(Railway يعطيك هذا تلقائياً)

JWT_SECRET=<قيمة عشوائية 32 بايت>
JWT_REFRESH_SECRET=<قيمة عشوائية 32 بايت>
HASH_SECRET=<قيمة عشوائية 32 بايت>
ENCRYPTION_KEY=<قيمة عشوائية 32 بايت>

AI_PROVIDER=groq
AI_USE_REAL_LLM=true
GROQ_API_KEY=<مفتاح Groq الجديد>
GROQ_MODEL=llama-3.3-70b-versatile

EMAIL_PROVIDER_API_KEY=<مفتاح Resend الجديد>
EMAIL_FROM_ADDRESS=noreply@yourdomain.com

JVZOO_SECRET_KEY=<من لوحة JVZoo>
FRONTEND_BASE_URL=https://your-app.railway.app
```

---

## النشر على VPS (Docker)

```bash
# 1. انسخ .env.production إلى .env وعبئه
cp .env.production .env
nano .env

# 2. شغّل
docker compose up -d

# 3. تحقق
curl https://your-domain.com/api/health
```

---

## بعد النشر — تحقق من هذه النقاط:

```
□ GET /api/health → { status: "ok" }
□ سجّل حساب جديد
□ فعّل ترخيص تجريبي: ALK-DEMO-TEST-0001-0001
□ أنشئ حملة وتحقق من توليد المحتوى
□ صدّر حملة وتحقق من تنزيل ZIP
```

---

## ملاحظة مهمة: Resend

للإرسال من دومينك الحقيقي (مثل noreply@yoursite.com):
1. resend.com → Domains → Add Domain
2. أضف DNS records المطلوبة
3. غيّر EMAIL_FROM_ADDRESS لدومينك

قبل ذلك يعمل من onboarding@resend.dev (للاختبار فقط)
